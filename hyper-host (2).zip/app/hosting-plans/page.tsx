'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { FaServer } from 'react-icons/fa'
import Layout from '../../components/Layout'

const PlanCard = ({ title, price, features }) => (
  <motion.div
    className="bg-gray-800 text-white p-6 rounded-lg shadow-lg"
    whileHover={{ scale: 1.05 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <FaServer className="text-4xl mb-4 text-white mx-auto" />
    <h3 className="text-2xl font-bold mb-2 text-center">{title}</h3>
    <p className="text-3xl font-bold mb-4 text-center">{price}</p>
    <ul className="text-left mb-6">
      {features.map((feature, index) => (
        <li key={index} className="mb-2 flex items-center">
          <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M5 13l4 4L19 7"></path>
          </svg>
          {feature}
        </li>
      ))}
    </ul>
    <button className="w-full bg-white text-black py-2 rounded-full hover:bg-gray-200 transition-colors">
      Choose Plan
    </button>
  </motion.div>
)

const HostingPlans = () => {
  const plans = [
    {
      title: "DIRT PLAN",
      price: "₹70/monthly",
      features: [
        "CPU - 100%",
        "RAM - 2GB",
        "SSD - 6GB"
      ]
    },
    {
      title: "OAK PLAN",
      price: "₹150/monthly",
      features: [
        "CPU - 150%",
        "RAM - 4GB",
        "SSD - 15GB"
      ]
    },
    {
      title: "STONE PLAN",
      price: "₹250/monthly",
      features: [
        "CPU - 200%",
        "RAM - 6GB",
        "SSD - 25GB"
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Hosting Plans</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <PlanCard key={index} {...plan} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default HostingPlans

