'use client'

import React from 'react'
import { motion } from 'framer-motion'
import Layout from '../../components/Layout'
import { FaBolt, FaLock, FaCloud, FaHeadset, FaRocket, FaCogs } from 'react-icons/fa'

const FeatureCard = ({ icon: Icon, title, description }) => (
  <motion.div
    className="bg-white text-black p-6 rounded-lg shadow-lg"
    whileHover={{ scale: 1.05 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <Icon className="text-4xl mb-4 text-gray-800 mx-auto" />
    <h3 className="text-xl font-bold mb-2 text-center">{title}</h3>
    <p className="text-center">{description}</p>
  </motion.div>
)

const Features = () => {
  const features = [
    {
      icon: FaBolt,
      title: "High Performance",
      description: "Lightning-fast servers optimized for speed and efficiency."
    },
    {
      icon: FaLock,
      title: "Advanced Security",
      description: "State-of-the-art security measures to protect your data."
    },
    {
      icon: FaCloud,
      title: "Cloud Integration",
      description: "Seamless integration with popular cloud services."
    },
    {
      icon: FaHeadset,
      title: "24/7 Support",
      description: "Round-the-clock expert support for all your hosting needs."
    },
    {
      icon: FaRocket,
      title: "Scalability",
      description: "Easily scale your resources as your needs grow."
    },
    {
      icon: FaCogs,
      title: "Custom Solutions",
      description: "Tailored hosting solutions to fit your specific requirements."
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Our Features</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default Features

