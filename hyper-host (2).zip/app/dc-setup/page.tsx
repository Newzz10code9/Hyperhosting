'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { FaDiscord, FaRobot, FaUsers } from 'react-icons/fa'
import Layout from '../../components/Layout'

const SetupCard = ({ title, icon: Icon, plans }) => (
  <motion.div
    className="bg-gray-800 text-white p-6 rounded-lg shadow-lg border border-gray-700"
    whileHover={{ scale: 1.02 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <motion.div
      initial={{ rotate: 0 }}
      animate={{ rotate: 360 }}
      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
    >
      <Icon className="text-4xl mb-4 text-gray-300 mx-auto" />
    </motion.div>
    <h3 className="text-2xl font-bold mb-4 text-center">{title}</h3>
    <ul className="text-left mb-6 space-y-2">
      {plans.map((plan, index) => (
        <motion.li 
          key={index} 
          className="flex justify-between items-center py-2 border-b border-gray-700"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <span className="font-medium">{plan.name}</span>
          <span className="text-gray-300">{plan.price}</span>
        </motion.li>
      ))}
    </ul>
    <motion.button
      className="w-full bg-white text-black py-2 rounded-full hover:bg-gray-200 transition-colors font-semibold flex items-center justify-center"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      Get Started
      <motion.span
        className="ml-2"
        initial={{ x: 0 }}
        animate={{ x: 5 }}
        transition={{ repeat: Infinity, duration: 0.8, repeatType: "reverse" }}
      >
        →
      </motion.span>
    </motion.button>
  </motion.div>
)

const DCSetup = () => {
  const setupTypes = [
    {
      title: "Basic Discord Setup",
      icon: FaDiscord,
      plans: [
        { name: "Channels Only", price: "30RS" },
        { name: "With Roles", price: "50RS" },
        { name: "Custom Categories", price: "70RS" }
      ]
    },
    {
      title: "Bot Integration",
      icon: FaRobot,
      plans: [
        { name: "Basic Bot Setup", price: "50RS" },
        { name: "Custom Commands", price: "100RS" },
        { name: "Advanced Automation", price: "150RS" }
      ]
    },
    {
      title: "Community Features",
      icon: FaUsers,
      plans: [
        { name: "Welcome System", price: "40RS" },
        { name: "Leveling System", price: "80RS" },
        { name: "Custom Events", price: "120RS" }
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen bg-black text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.h1 
            className="text-4xl font-bold text-center mb-12"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Discord Server Setup Services
          </motion.h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {setupTypes.map((setup, index) => (
              <motion.div
                key={setup.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <SetupCard {...setup} />
              </motion.div>
            ))}
          </div>
          <motion.div 
            className="mt-12 text-center text-gray-400 bg-gray-800 p-6 rounded-lg shadow-lg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <h2 className="text-2xl font-bold mb-4 text-white">Why Choose Our Discord Setup Service?</h2>
            <ul className="space-y-2">
              <li>Professional and customized server structure</li>
              <li>Integration with popular bots and custom bot development</li>
              <li>Engaging community features to boost member activity</li>
              <li>Ongoing support and maintenance options available</li>
            </ul>
          </motion.div>
        </div>
      </div>
    </Layout>
  )
}

export default DCSetup

