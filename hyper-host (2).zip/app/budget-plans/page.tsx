'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { FaPiggyBank } from 'react-icons/fa'
import Layout from '../../components/Layout'

const PlanCard = ({ title, price, features }) => (
  <motion.div
    className="bg-gray-800 text-white p-6 rounded-lg shadow-lg"
    whileHover={{ scale: 1.05 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <FaPiggyBank className="text-4xl mb-4 text-green-500 mx-auto" />
    <h3 className="text-2xl font-bold mb-2 text-center">{title}</h3>
    <p className="text-3xl font-bold mb-4 text-center">{price}</p>
    <ul className="text-left mb-6">
      {features.map((feature, index) => (
        <li key={index} className="mb-2 flex items-center">
          <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M5 13l4 4L19 7"></path>
          </svg>
          {feature}
        </li>
      ))}
    </ul>
    <button className="w-full bg-green-500 text-black py-2 rounded-full hover:bg-green-400 transition-colors">
      Choose Plan
    </button>
  </motion.div>
)

const BudgetPlans = () => {
  const plans = [
    {
      title: "BUDGET DIRT",
      price: "₹39.00/m",
      features: [
        "RAM - 1GB DDR5",
        "CPU - 20%",
        "DISK - 3GB"
      ]
    },
    {
      title: "BUDGET STONE PLAN",
      price: "₹69.00/m",
      features: [
        "RAM - 2GB DDR5",
        "CPU - 50%",
        "DISK - 5GB"
      ]
    },
    {
      title: "BUDGET COPPER PLAN",
      price: "₹89.00/m",
      features: [
        "RAM - 4GB DDR5",
        "CPU - 80%",
        "DISK - 8GB"
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Budget Plans</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <PlanCard key={index} {...plan} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default BudgetPlans

