'use client'

import React from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import { FaServer, FaRocket, FaGem } from 'react-icons/fa'

const PlanCard = ({ title, price, features, icon: Icon }) => (
  <motion.div
    className="bg-white text-black p-6 rounded-lg shadow-lg"
    whileHover={{ scale: 1.05 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <Icon className="text-4xl mb-4 text-blue-600" />
    <h3 className="text-2xl font-bold mb-2">{title}</h3>
    <p className="text-3xl font-bold mb-4">{price}</p>
    <ul className="text-left mb-6">
      {features.map((feature, index) => (
        <li key={index} className="mb-2 flex items-center">
          <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M5 13l4 4L19 7"></path>
          </svg>
          {feature}
        </li>
      ))}
    </ul>
    <button className="w-full bg-blue-600 text-white py-2 rounded-full hover:bg-blue-700 transition-colors">
      Choose Plan
    </button>
  </motion.div>
)

const Plans = () => {
  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-12">Hosting Plans</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <PlanCard
            title="STARTER VPS PLAN"
            price="₹2000"
            features={[
              "Website Setup",
              "Dashboard Setup",
              "Panel & node Setup",
              "DISCORD SETUP"
            ]}
            icon={FaServer}
          />
          <PlanCard
            title="DIAMOND VPS PLAN"
            price="₹6500"
            features={[
              "Website (best)",
              "Panel & node (theme)",
              "Dashboard (Custom buildup)",
              "32 GB RAM VPS (India location)",
              "DISCORD SETUP"
            ]}
            icon={FaGem}
          />
          <PlanCard
            title="HYPER VPS PLAN"
            price="₹11,000"
            features={[
              "DASHBOARD",
              "(THEME & ADDONS) PANEL & NODE SETUP",
              "DISCORD SETUP",
              "32 GB * 2 VPS (INDIA MUMBAI)",
              "WEBSITE (CUSTOM)",
              "DOMAIN FOR 1 YEAR"
            ]}
            icon={FaRocket}
          />
        </div>

        <h2 className="text-3xl font-bold text-center mb-8">VPS Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <PlanCard
            title="32 GB RAM"
            price="₹800"
            features={[
              "IP Protected DDOS",
              "Full Root Access",
              "24/7 VIP Support"
            ]}
            icon={FaServer}
          />
          <PlanCard
            title="64 GB RAM"
            price="₹1000"
            features={[
              "IP Protected DDOS",
              "Full Root Access",
              "24/7 VIP Support"
            ]}
            icon={FaServer}
          />
          <PlanCard
            title="128 GB RAM"
            price="₹1200"
            features={[
              "IP Protected DDOS",
              "Full Root Access",
              "24/7 VIP Support"
            ]}
            icon={FaServer}
          />
        </div>

        <h2 className="text-3xl font-bold text-center mb-8">Minecraft Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <PlanCard
            title="DIRT PLAN"
            price="₹70/monthly"
            features={[
              "CPU - 100%",
              "RAM - 2GB",
              "SSD - 6GB"
            ]}
            icon={FaServer}
          />
          <PlanCard
            title="OAK PLAN"
            price="₹150/monthly"
            features={[
              "CPU - 150%",
              "RAM - 4GB",
              "SSD - 15GB"
            ]}
            icon={FaServer}
          />
          <PlanCard
            title="STONE PLAN"
            price="₹250/monthly"
            features={[
              "CPU - 200%",
              "RAM - 6GB",
              "SSD - 25GB"
            ]}
            icon={FaServer}
          />
        </div>

        <h2 className="text-3xl font-bold text-center mb-8">Budget Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <PlanCard
            title="BUDGET DIRT"
            price="₹39.00/m"
            features={[
              "RAM - 1GB DDR5",
              "CPU - 20%",
              "DISK - 3GB"
            ]}
            icon={FaServer}
          />
          <PlanCard
            title="BUDGET STONE PLAN"
            price="₹69.00/m"
            features={[
              "RAM - 2GB DDR5",
              "CPU - 50%",
              "DISK - 5GB"
            ]}
            icon={FaServer}
          />
          <PlanCard
            title="BUDGET COPPER PLAN"
            price="₹89.00/m"
            features={[
              "RAM - 4GB DDR5",
              "CPU - 80%",
              "DISK - 8GB"
            ]}
            icon={FaServer}
          />
        </div>

        <h2 className="text-3xl font-bold text-center mb-8">Domain Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-4">Basic Domains</h3>
            <ul className="space-y-2">
              <li>.fun - ₹150 / Yearly</li>
              <li>.site - ₹150 / Yearly</li>
              <li>.store - ₹150 / Yearly</li>
              <li>.shop - ₹150 / Yearly</li>
            </ul>
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-4">Standard Domains</h3>
            <ul className="space-y-2">
              <li>.xyz - ₹250 / Yearly</li>
              <li>.online - ₹300 / Yearly</li>
              <li>.tech - ₹300 / Yearly</li>
              <li>.cloud - ₹300 / Yearly</li>
              <li>.in - ₹350 / Yearly</li>
              <li>.pro - ₹350 / Yearly</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Link href="/contact">
            <button className="bg-blue-600 text-white py-3 px-6 rounded-full hover:bg-blue-700 transition-colors text-lg font-semibold">
              Contact Us for Custom Plans
            </button>
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Plans

