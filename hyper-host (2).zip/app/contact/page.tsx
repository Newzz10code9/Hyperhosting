'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { FaDiscord, FaEnvelope } from 'react-icons/fa'
import Layout from '../../components/Layout'

const ContactInfo = ({ icon: Icon, title, content }) => (
  <motion.div
    className="flex items-center space-x-4 mb-8 bg-gray-700 p-6 rounded-lg shadow-lg"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
    whileHover={{ scale: 1.05 }}
  >
    <motion.div
      initial={{ rotate: 0 }}
      animate={{ rotate: 360 }}
      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
    >
      <Icon className="text-5xl text-blue-400" />
    </motion.div>
    <div>
      <motion.h3 
        className="text-2xl font-bold text-white mb-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        {title}
      </motion.h3>
      <motion.p 
        className="text-gray-300"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        {content}
      </motion.p>
    </div>
  </motion.div>
)

const Contact = () => {
  return (
    <Layout>
      <motion.div 
        className="min-h-screen py-12 px-4 sm:px-6 lg:px-8 bg-gray-900"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-3xl mx-auto">
          <motion.h1 
            className="text-5xl font-bold text-center mb-12 text-white"
            initial={{ y: -50 }}
            animate={{ y: 0 }}
            transition={{ type: "spring", stiffness: 100 }}
          >
            Contact Us
          </motion.h1>
          <div className="space-y-6">
            <ContactInfo
              icon={FaDiscord}
              title="Join our Discord"
              content={
                <a
                  href="https://discord.gg/nZyzhxmBpM"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:underline"
                >
                  https://discord.gg/nZyzhxmBpM
                </a>
              }
            />
            <ContactInfo
              icon={FaDiscord}
              title="Contact Notfire62"
              content="Discord ID: notfire62"
            />
            <ContactInfo
              icon={FaEnvelope}
              title="Email Us"
              content="support@hyperhost.com"
            />
          </div>
        </div>
      </motion.div>
    </Layout>
  )
}

export default Contact

