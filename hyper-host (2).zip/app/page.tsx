'use client'

import React from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { useCallback } from 'react'
import Particles from 'react-tsparticles'
import { loadSlim } from "tsparticles-slim"
import type { Engine } from 'tsparticles-engine'
import Layout from '../components/Layout'
import { FaServer, FaRocket, FaShieldAlt } from 'react-icons/fa'
import Setups from './setups/page'

const AnimatedButton = ({ children }) => (
  <motion.button
    whileHover={{ scale: 1.05 }}
    whileTap={{ scale: 0.95 }}
    className="px-6 py-3 bg-white text-black font-bold rounded-full shadow-lg hover:bg-gray-200 transition-colors duration-300"
  >
    {children}
  </motion.button>
)

export default function Home() {
  const particlesInit = useCallback(async (engine: Engine) => {
    await loadSlim(engine)
  }, [])

  return (
    <Layout>
      <div className="relative z-10">
        <Particles
          id="tsparticles"
          init={particlesInit}
          options={{
            fullScreen: { enable: false },
            background: {
              color: {
                value: "transparent",
              },
            },
            fpsLimit: 120,
            interactivity: {
              events: {
                onClick: {
                  enable: true,
                  mode: "push",
                },
                onHover: {
                  enable: true,
                  mode: "repulse",
                },
                resize: true,
              },
              modes: {
                push: {
                  quantity: 4,
                },
                repulse: {
                  distance: 200,
                  duration: 0.4,
                },
              },
            },
            particles: {
              color: {
                value: "#ffffff",
              },
              links: {
                color: "#ffffff",
                distance: 150,
                enable: true,
                opacity: 0.5,
                width: 1,
              },
              move: {
                direction: "none",
                enable: true,
                outModes: {
                  default: "bounce",
                },
                random: false,
                speed: 2,
                straight: false,
              },
              number: {
                density: {
                  enable: true,
                  area: 800,
                },
                value: 40,
              },
              opacity: {
                value: 0.5,
              },
              shape: {
                type: "circle",
              },
              size: {
                value: { min: 1, max: 5 },
              },
            },
            detectRetina: true,
          }}
          className="absolute inset-0"
        />
        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <Image
              src="https://media.discordapp.net/attachments/1328345961495396392/1328351837396537375/0106.gif?ex=6786638d&is=6785120d&hm=8bbdb836d01b3e1d015723b3a72f3f02346e33913a5f2d2fb32f37e97f4e98c2&"
              alt="Hyper Host Logo"
              width={200}
              height={200}
              className="rounded-full mb-8"
            />
          </motion.div>
          <motion.h1
            className="text-5xl font-bold mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
          >
            Welcome to Hyper Host
          </motion.h1>
          <motion.p
            className="text-xl mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7, duration: 1 }}
          >
            Lightning-fast hosting solutions for your digital needs
          </motion.p>
          <motion.div
            className="flex space-x-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9, duration: 1 }}
          >
            <Link href="/vps-plans">
              <AnimatedButton>View Plans</AnimatedButton>
            </Link>
            <Link href="/contact">
              <AnimatedButton>Contact Us</AnimatedButton>
            </Link>
            <Link href="/setups">
              <AnimatedButton>Setups</AnimatedButton>
            </Link>
          </motion.div>
        </div>
      </div>
      <section className="relative z-10 bg-black text-white py-20">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {[
        { title: 'Web Hosting', description: 'Fast and reliable hosting for your websites', icon: FaServer },
        { title: 'VPS', description: 'Virtual Private Servers for enhanced performance', icon: FaRocket },
        { title: 'Dedicated Servers', description: 'Powerful dedicated hardware for your applications', icon: FaShieldAlt },
      ].map((service, index) => (
        <motion.div
          key={index}
          className="bg-gray-800 p-6 rounded-lg shadow-md"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.2 }}
        >
          <service.icon className="text-4xl mb-4 text-white mx-auto" />
          <h3 className="text-xl font-bold mb-2 text-center">{service.title}</h3>
          <p className="text-center">{service.description}</p>
        </motion.div>
      ))}
    </div>
  </div>
</section>
      <section className="relative z-10 py-20">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h2 className="text-3xl font-bold text-center mb-12">Why Choose Hyper Host?</h2>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {[
        { title: 'Blazing Fast Speed', description: 'Our optimized infrastructure ensures your content is delivered at lightning speed.' },
        { title: '99.9% Uptime', description: 'We guarantee high availability for your services.' },
        { title: '24/7 Support', description: 'Our expert team is always ready to assist you.' },
        { title: 'Scalable Solutions', description: 'Easily upgrade your resources as your needs grow.' },
      ].map((feature, index) => (
        <motion.div
          key={index}
          className="bg-gray-900 p-6 rounded-lg"
          initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          viewport={{ once: true }}
        >
          <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
          <p>{feature.description}</p>
        </motion.div>
      ))}
    </div>
  </div>
</section>
    </Layout>
  )
}

