'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { FaGift } from 'react-icons/fa'
import Layout from '../../components/Layout'

const FreePlan = () => (
  <motion.div
    className="bg-gray-800 text-white p-6 rounded-lg shadow-lg max-w-2xl mx-auto"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
  >
    <FaGift className="text-4xl mb-4 text-green-500 mx-auto" />
    <h3 className="text-2xl font-bold mb-2 text-center">Free Plan</h3>
    <ul className="text-left mb-6">
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        RAM = 3 GB
      </li>
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        CPU = 100%
      </li>
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        DISK = 4 GB
      </li>
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        LOCATION = Indian, Singapore, and other locations coming soon
      </li>
    </ul>
    <div className="text-center">
      <p className="font-bold mb-4">Requirements:</p>
      <ul className="list-disc list-inside mb-4">
        <li>5 Invites</li>
        <li>Set "HYPER HOSTING ON TOP" link in bio</li>
        <li>Set Discord link "dsc.gg/nZyzhxmBpM" in status</li>
      </ul>
      <p className="text-sm text-gray-400">
        By setting this in your status, you can get a server with just 3 invites!
      </p>
      <p className="text-sm text-gray-400 mt-2">
        Note: You need monthly invites to maintain the free plan.
      </p>
    </div>
  </motion.div>
)

const FreePlans = () => {
  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Free Plan</h1>
          <FreePlan />
        </div>
      </div>
    </Layout>
  )
}

export default FreePlans

