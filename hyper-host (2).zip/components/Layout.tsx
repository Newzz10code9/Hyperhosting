'use client'

import React, { useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { FaHome, FaServer, FaGlobe, FaCrown, FaPiggyBank, FaBolt, FaGift, FaTools, FaEnvelope, FaDiscord, FaTimes, FaStar, FaCube, FaGamepad } from 'react-icons/fa'

const Sidebar = ({ isOpen, toggleSidebar }) => (
  <motion.div
    className={`fixed top-0 left-0 h-full w-64 bg-gray-900 text-white z-50 transform ${
      isOpen ? 'translate-x-0' : '-translate-x-full'
    } transition-transform duration-300 ease-in-out`}
    initial={false}
    animate={{ x: isOpen ? 0 : '-100%' }}
  >
    <div className="p-5">
      <Image
        src="https://media.discordapp.net/attachments/1328345961495396392/1328351837396537375/0106.gif?ex=6786638d&is=6785120d&hm=8bbdb836d01b3e1d015723b3a72f3f02346e33913a5f2d2fb32f37e97f4e98c2&"
        alt="Hyper Host Logo"
        width={50}
        height={50}
        className="rounded-full mb-4"
      />
      <h2 className="text-2xl font-bold mb-5">Hyper Host</h2>
      <nav>
        <ul className="space-y-2">
          <li>
            <Link href="/" className="flex items-center space-x-2 hover:text-gray-300">
              <FaHome />
              <span>Home</span>
            </Link>
          </li>
          <li>
            <Link href="/vps-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaServer />
              <span>VPS Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/hosting-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaGlobe />
              <span>Hosting Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/premium-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaCrown />
              <span>Premium Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/budget-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaPiggyBank />
              <span>Budget Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/boost-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaBolt />
              <span>Boost Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/free-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaGift />
              <span>Free Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/features" className="flex items-center space-x-2 hover:text-gray-300">
              <FaStar />
              <span>Features</span>
            </Link>
          </li>
          <li>
            <Link href="/dc-setup" className="flex items-center space-x-2 hover:text-gray-300">
              <FaDiscord />
              <span>Discord Setup</span>
            </Link>
          </li>
          <li>
            <Link href="/mc-setup" className="flex items-center space-x-2 hover:text-gray-300">
              <FaGamepad />
              <span>Minecraft Setup</span>
            </Link>
          </li>
          <li>
            <Link href="/contact" className="flex items-center space-x-2 hover:text-gray-300">
              <FaEnvelope />
              <span>Contact</span>
            </Link>
          </li>
          <li>
            <a href="https://discord.gg/nZyzhxmBpM" target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 hover:text-gray-300">
              <FaDiscord />
              <span>Join Discord</span>
            </a>
          </li>
        </ul>
      </nav>
      <button
        onClick={toggleSidebar}
        className="absolute top-4 right-4 text-white hover:text-gray-300"
      >
        <FaTimes />
      </button>
    </div>
  </motion.div>
)

const Navbar = ({ toggleSidebar }) => (
  <nav className="fixed top-0 left-0 right-0 z-40 bg-black bg-opacity-50 backdrop-blur-md">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between h-16">
        <div className="flex items-center">
          <button onClick={toggleSidebar} className="text-white p-2">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <Image
            src="https://media.discordapp.net/attachments/1328345961495396392/1328351837396537375/0106.gif?ex=6786638d&is=6785120d&hm=8bbdb836d01b3e1d015723b3a72f3f02346e33913a5f2d2fb32f37e97f4e98c2&"
            alt="Hyper Host Logo"
            width={50}
            height={50}
            className="rounded-full ml-2"
          />
          <span className="ml-2 text-xl font-bold text-white">Hyper Host</span>
        </div>
      </div>
    </div>
  </nav>
)

const Layout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen)

  return (
    <div className="min-h-screen bg-black text-white">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      <Navbar toggleSidebar={toggleSidebar} />
      <div className="pt-16 pl-0 md:pl-64 transition-all duration-300">
        <main className="p-4">{children}</main>
      </div>
    </div>
  )
}

export default Layout

