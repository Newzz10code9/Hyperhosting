'use client'

import React, { useState, useCallback } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import Particles from 'react-tsparticles'
import { loadSlim } from "tsparticles-slim"
import type { Engine } from 'tsparticles-engine'
import { FaServer, FaRocket, FaShieldAlt, FaHome, FaGlobe, FaCrown, FaPiggyBank, FaBolt, FaGift, FaTools, FaEnvelope, FaDiscord, FaTimes, FaStar, FaLock, FaCloud, FaHeadset, FaCogs, FaCube, FaGamepad } from 'react-icons/fa'
import DCSetup from './app/dc-setup/page'
import MCSetup from './app/mc-setup/page'
import Setups from './app/setups/page'

// Layout Component
const Layout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen)

  return (
    <div className="min-h-screen bg-black text-white flex">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      <div className="flex-1 pt-16 pl-0 md:pl-64 transition-all duration-300">
        <main className="p-4">{children}</main>
      </div>
    </div>
  )
}

// Sidebar Component
const Sidebar = ({ isOpen, toggleSidebar }) => (
  <motion.div
    className={`fixed top-0 left-0 h-full w-64 bg-gray-900 text-white z-50 transform ${
      isOpen ? 'translate-x-0' : '-translate-x-full'
    } transition-transform duration-300 ease-in-out`}
    initial={false}
    animate={{ x: isOpen ? 0 : '-100%' }}
  >
    <div className="p-5">
      <Image
        src="https://media.discordapp.net/attachments/1328345961495396392/1328351837396537375/0106.gif?ex=6786638d&is=6785120d&hm=8bbdb836d01b3e1d015723b3a72f3f02346e33913a5f2d2fb32f37e97f4e98c2&"
        alt="Hyper Host Logo"
        width={50}
        height={50}
        className="rounded-full mb-4"
      />
      <h2 className="text-2xl font-bold mb-5">Hyper Host</h2>
      <nav>
        <ul className="space-y-2">
          <li>
            <Link href="/" className="flex items-center space-x-2 hover:text-gray-300">
              <FaHome />
              <span>Home</span>
            </Link>
          </li>
          <li>
            <Link href="/vps-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaServer />
              <span>VPS Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/hosting-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaGlobe />
              <span>Hosting Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/premium-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaCrown />
              <span>Premium Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/budget-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaPiggyBank />
              <span>Budget Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/boost-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaBolt />
              <span>Boost Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/free-plans" className="flex items-center space-x-2 hover:text-gray-300">
              <FaGift />
              <span>Free Plans</span>
            </Link>
          </li>
          <li>
            <Link href="/features" className="flex items-center space-x-2 hover:text-gray-300">
              <FaStar />
              <span>Features</span>
            </Link>
          </li>
          <li>
            <Link href="/setups" className="flex items-center space-x-2 hover:text-gray-300">
              <FaTools />
              <span>Setups</span>
            </Link>
          </li>
          <li>
            <Link href="/contact" className="flex items-center space-x-2 hover:text-gray-300">
              <FaEnvelope />
              <span>Contact</span>
            </Link>
          </li>
          <li>
            <a href="https://discord.gg/nZyzhxmBpM" target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 hover:text-gray-300">
              <FaDiscord />
              <span>Join Discord</span>
            </a>
          </li>
        </ul>
      </nav>
      <button
        onClick={toggleSidebar}
        className="absolute top-4 right-4 text-white hover:text-gray-300"
      >
        <FaTimes />
      </button>
    </div>
  </motion.div>
)

// Navbar Component
const Navbar = ({ toggleSidebar }) => (
  <nav className="fixed top-0 left-0 right-0 z-40 bg-black bg-opacity-50 backdrop-blur-md">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between h-16">
        <div className="flex items-center">
          <button onClick={toggleSidebar} className="text-white p-2">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <Image
            src="https://media.discordapp.net/attachments/1328345961495396392/1328351837396537375/0106.gif?ex=6786638d&is=6785120d&hm=8bbdb836d01b3e1d015723b3a72f3f02346e33913a5f2d2fb32f37e97f4e98c2&"
            alt="Hyper Host Logo"
            width={50}
            height={50}
            className="rounded-full ml-2"
          />
          <span className="ml-2 text-xl font-bold text-white">Hyper Host</span>
        </div>
      </div>
    </div>
  </nav>
)

// Home Page
const Home = () => {
  const particlesInit = useCallback(async (engine: Engine) => {
    await loadSlim(engine)
  }, [])

  return (
    <Layout>
      <div className="relative z-10">
        <Particles
          id="tsparticles"
          init={particlesInit}
          options={{
            fullScreen: { enable: false },
            background: {
              color: {
                value: "transparent",
              },
            },
            fpsLimit: 120,
            interactivity: {
              events: {
                onClick: {
                  enable: true,
                  mode: "push",
                },
                onHover: {
                  enable: true,
                  mode: "repulse",
                },
                resize: true,
              },
              modes: {
                push: {
                  quantity: 4,
                },
                repulse: {
                  distance: 200,
                  duration: 0.4,
                },
              },
            },
            particles: {
              color: {
                value: "#ffffff",
              },
              links: {
                color: "#ffffff",
                distance: 150,
                enable: true,
                opacity: 0.5,
                width: 1,
              },
              move: {
                direction: "none",
                enable: true,
                outModes: {
                  default: "bounce",
                },
                random: false,
                speed: 2,
                straight: false,
              },
              number: {
                density: {
                  enable: true,
                  area: 800,
                },
                value: 40,
              },
              opacity: {
                value: 0.5,
              },
              shape: {
                type: "circle",
              },
              size: {
                value: { min: 1, max: 5 },
              },
            },
            detectRetina: true,
          }}
          className="absolute inset-0"
        />
        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <Image
              src="https://media.discordapp.net/attachments/1328345961495396392/1328351837396537375/0106.gif?ex=6786638d&is=6785120d&hm=8bbdb836d01b3e1d015723b3a72f3f02346e33913a5f2d2fb32f37e97f4e98c2&"
              alt="Hyper Host Logo"
              width={200}
              height={200}
              className="rounded-full mb-8"
            />
          </motion.div>
          <motion.h1
            className="text-5xl font-bold mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
          >
            Welcome to Hyper Host
          </motion.h1>
          <motion.p
            className="text-xl mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7, duration: 1 }}
          >
            Lightning-fast hosting solutions for your digital needs
          </motion.p>
          <motion.div
            className="flex space-x-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9, duration: 1 }}
          >
            <Link href="/vps-plans">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-white text-black font-bold rounded-full shadow-lg hover:bg-gray-200 transition-colors duration-300"
              >
                View Plans
              </motion.button>
            </Link>
            <Link href="/contact">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-white text-black font-bold rounded-full shadow-lg hover:bg-gray-200 transition-colors duration-300"
              >
                Contact Us
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </div>
      <section className="relative z-10 bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Web Hosting', description: 'Fast and reliable hosting for your websites', icon: FaServer },
              { title: 'VPS', description: 'Virtual Private Servers for enhanced performance', icon: FaRocket },
              { title: 'Dedicated Servers', description: 'Powerful dedicated hardware for your applications', icon: FaShieldAlt },
            ].map((service, index) => (
              <motion.div
                key={index}
                className="bg-gray-800 p-6 rounded-lg shadow-md"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <service.icon className="text-4xl mb-4 text-white mx-auto" />
                <h3 className="text-xl font-bold mb-2 text-center">{service.title}</h3>
                <p className="text-center">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      <section className="relative z-10 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Hyper Host?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              { title: 'Blazing Fast Speed', description: 'Our optimized infrastructure ensures your content is delivered at lightning speed.' },
              { title: '99.9% Uptime', description: 'We guarantee high availability for your services.' },
              { title: '24/7 Support', description: 'Our expert team is always ready to assist you.' },
              { title: 'Scalable Solutions', description: 'Easily upgrade your resources as your needs grow.' },
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="bg-gray-900 p-6 rounded-lg"
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p>{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  )
}

// VPS Plans Page
const VPSPlans = () => {
  const plans = [
    {
      title: "32 GB RAM",
      price: "₹800",
      features: [
        "IP Protected DDOS",
        "Full Root Access",
        "24/7 VIP Support"
      ]
    },
    {
      title: "64 GB RAM",
      price: "₹1000",
      features: [
        "IP Protected DDOS",
        "Full Root Access",
        "24/7 VIP Support"
      ]
    },
    {
      title: "128 GB RAM",
      price: "₹1200",
      features: [
        "IP Protected DDOS",
        "Full Root Access",
        "24/7 VIP Support"
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">VPS Plans</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <PlanCard key={index} {...plan} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}

// Hosting Plans Page
const HostingPlans = () => {
  const plans = [
    {
      title: "DIRT PLAN",
      price: "₹70/monthly",
      features: [
        "CPU - 100%",
        "RAM - 2GB",
        "SSD - 6GB"
      ]
    },
    {
      title: "OAK PLAN",
      price: "₹150/monthly",
      features: [
        "CPU - 150%",
        "RAM - 4GB",
        "SSD - 15GB"
      ]
    },
    {
      title: "STONE PLAN",
      price: "₹250/monthly",
      features: [
        "CPU - 200%",
        "RAM - 6GB",
        "SSD - 25GB"
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Hosting Plans</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <PlanCard key={index} {...plan} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}

// Premium Plans Page
const PremiumPlans = () => {
  const plans = [
    {
      title: "COAL PLAN",
      price: "₹239/monthly",
      features: [
        "RAM - 8GB",
        "CPU - 250%",
        "SSD - 35GB"
      ]
    },
    {
      title: "IRON PLAN",
      price: "₹350/monthly",
      features: [
        "CPU - 300%",
        "RAM - 10GB",
        "SSD - 40GB"
      ]
    },
    {
      title: "DIAMOND PLAN",
      price: "₹400/monthly",
      features: [
        "CPU - 350%",
        "RAM - 12GB",
        "SSD - 50GB"
      ]
    },
    {
      title: "NETHERITE PLAN",
      price: "₹500/monthly",
      features: [
        "CPU - 450%",
        "RAM - 16GB",
        "SSD - 60GB"
      ]
    },
    {
      title: "OBSIDIAN PLAN",
      price: "₹900/monthly",
      features: [
        "CPU - 900%",
        "RAM - 32GB",
        "SSD - 90GB"
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Premium Plans</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <PlanCard key={index} {...plan} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}

// Budget Plans Page
const BudgetPlans = () => {
  const plans = [
    {
      title: "BUDGET DIRT",
      price: "₹39.00/m",
      features: [
        "RAM - 1GB DDR5",
        "CPU - 20%",
        "DISK - 3GB"
      ]
    },
    {
      title: "BUDGET STONE PLAN",
      price: "₹69.00/m",
      features: [
        "RAM - 2GB DDR5",
        "CPU - 50%",
        "DISK - 5GB"
      ]
    },
    {
      title: "BUDGET COPPER PLAN",
      price: "₹89.00/m",
      features: [
        "RAM - 4GB DDR5",
        "CPU - 80%",
        "DISK - 8GB"
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Budget Plans</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <PlanCard key={index} {...plan} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}

// Boost Plans Page
const BoostPlans = () => {
  const plans = [
    {
      title: "1 Boost",
      price: "2 GB RAM Server",
      features: [
        "Indian nodes",
        "Instant setup",
        "24/7 support"
      ]
    },
    {
      title: "2 Boosts",
      price: "4 GB RAM Server",
      features: [
        "Indian nodes",
        "Instant setup",
        "24/7 support",
        "Priority queue"
      ]
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Boost Plans</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {plans.map((plan, index) => (
              <PlanCard key={index} {...plan} />
            ))}
          </div>
          <p className="text-center mt-8 text-gray-400">
            If you already have a server, the boost will be added to your existing plan.
          </p>
        </div>
      </div>
    </Layout>
  )
}

// Free Plans Page
const FreePlans = () => {
  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Free Plan</h1>
          <FreePlan />
        </div>
      </div>
    </Layout>
  )
}

// Features Page
const Features = () => {
  const features = [
    {
      icon: FaBolt,
      title: "High Performance",
      description: "Lightning-fast servers optimized for speed and efficiency."
    },
    {
      icon: FaLock,
      title: "Advanced Security",
      description: "State-of-the-art security measures to protect your data."
    },
    {
      icon: FaCloud,
      title: "Cloud Integration",
      description: "Seamless integration with popular cloud services."
    },
    {
      icon: FaHeadset,
      title: "24/7 Support",
      description: "Round-the-clock expert support for all your hosting needs."
    },
    {
      icon: FaRocket,
      title: "Scalability",
      description: "Easily scale your resources as your needs grow."
    },
    {
      icon: FaCogs,
      title: "Custom Solutions",
      description: "Tailored hosting solutions to fit your specific requirements."
    }
  ]

  return (
    <Layout>
      <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-12">Our Features</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}


// Contact Page
const Contact = () => {
  return (
    <Layout>
      <motion.div 
        className="min-h-screen py-12 px-4 sm:px-6 lg:px-8 bg-gray-900"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-3xl mx-auto">
          <motion.h1 
            className="text-5xl font-bold text-center mb-12 text-white"
            initial={{ y: -50 }}
            animate={{ y: 0 }}
            transition={{ type: "spring", stiffness: 100 }}
          >
            Contact Us
          </motion.h1>
          <div className="space-y-6">
            <ContactInfo
              icon={FaDiscord}
              title="Join our Discord"
              content={
                <a
                  href="https://discord.gg/nZyzhxmBpM"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:underline"
                >
                  https://discord.gg/nZyzhxmBpM
                </a>
              }
            />
            <ContactInfo
              icon={FaDiscord}
              title="Contact Notfire62"
              content="Discord ID: notfire62"
            />
            <ContactInfo
              icon={FaEnvelope}
              title="Email Us"
              content="support@hyperhost.com"
            />
          </div>
        </div>
      </motion.div>
    </Layout>
  )
}

// Reusable Components
const PlanCard = ({ title, price, features }) => (
  <motion.div
    className="bg-gray-800 text-white p-6 rounded-lg shadow-lg"
    whileHover={{ scale: 1.05 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <FaServer className="text-4xl mb-4 text-white mx-auto" />
    <h3 className="text-2xl font-bold mb-2 text-center">{title}</h3>
    <p className="text-3xl font-bold mb-4 text-center">{price}</p>
    <ul className="text-left mb-6">
      {features.map((feature, index) => (
        <li key={index} className="mb-2 flex items-center">
          <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M5 13l4 4L19 7"></path>
          </svg>
          {feature}
        </li>
      ))}
    </ul>
    <button className="w-full bg-white text-black py-2 rounded-full hover:bg-gray-200 transition-colors">
      Choose Plan
    </button>
  </motion.div>
)

const FreePlan = () => (
  <motion.div
    className="bg-gray-800 text-white p-6 rounded-lg shadow-lg max-w-2xl mx-auto"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
  >
    <FaGift className="text-4xl mb-4 text-green-500 mx-auto" />
    <h3 className="text-2xl font-bold mb-2 text-center">Free Plan</h3>
    <ul className="text-left mb-6">
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        RAM = 3 GB
      </li>
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        CPU = 100%
      </li>
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        DISK = 4 GB
      </li>
      <li className="mb-2 flex items-center">
        <svg className="w-4 h-4 mr-2 text-green-500" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
        LOCATION = Indian, Singapore, and other locations coming soon
      </li>
    </ul>
    <div className="text-center">
      <p className="font-bold mb-4">Requirements:</p>
      <ul className="list-disc list-inside mb-4">
        <li>5 Invites</li>
        <li>Set "HYPER HOSTING ON TOP" link in bio</li>
        <li>Set Discord link "dsc.gg/nZyzhxmBpM" in status</li>
      </ul>
      <p className="text-sm text-gray-400">
        By setting this in your status, you can get a server with just 3 invites!
      </p>
      <p className="text-sm text-gray-400 mt-2">
        Note: You need monthly invites to maintain the free plan.
      </p>
    </div>
  </motion.div>
)

const FeatureCard = ({ icon: Icon, title, description }) => (
  <motion.div
    className="bg-gray-800 text-white p-6 rounded-lg shadow-lg"
    whileHover={{ scale: 1.05 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <Icon className="text-4xl mb-4 text-white mx-auto" />
    <h3 className="text-xl font-bold mb-2 text-center">{title}</h3>
    <p className="text-center">{description}</p>
  </motion.div>
)


const ContactInfo = ({ icon: Icon, title, content }) => (
  <motion.div
    className="flex items-center space-x-4 mb-8 bg-gray-700 p-6 rounded-lg shadow-lg"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
    whileHover={{ scale: 1.05 }}
  >
    <motion.div
      initial={{ rotate: 0 }}
      animate={{ rotate: 360 }}
      transition={{ duration: 2, repeat: Infinity, ease: "linear"    }}
    >
      <Icon className="text-5xl text-blue-400" />
    </motion.div>
    <div>      <motion.h3 className="text-2xl font-bold text-white mb-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        {title}
      </motion.h3>
      <motion.p 
        className="text-gray-300"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        {content}
      </motion.p>
    </div>
  </motion.div>
)

// Setups Page
const SetupsPage = () => <Setups />
const DCSetupsPage = () => <DCSetup />
const MCSetupsPage = () => <MCSetup />

export { Home, VPSPlans, HostingPlans, PremiumPlans, BudgetPlans, BoostPlans, FreePlans, Features, DCSetup, MCSetup, Contact }

